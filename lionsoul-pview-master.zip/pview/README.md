Pview是使用java开发的一款图片查看器.

1. 支持上下一张图片切换

2. 图片放大/缩小. (滚动支持...)

3. 图片旋转.

4. 大图片拖动查看.

用到的比较多的UI重写, 界面比较漂亮...

开源中国分享: http://www.oschina.net/code/snippet_853816_26667

图片效果:

<img src="http://static.oschina.net/uploads/code/201311/22152704_YYQg.png" />

<img src="http://static.oschina.net/uploads/code/201311/22152704_vf5c.png"/>

<img src="http://static.oschina.net/uploads/code/201311/22153436_mwax.jpg"/>

<img src="http://static.oschina.net/uploads/code/201311/22153436_SrBN.jpg"/>
